import { Component, OnInit } from '@angular/core';
import {MatTableDataSource} from '@angular/material/table';
import { UserService } from '../services/user.service';
import {Contact} from '../interfaces/contact.interface';
import { DataService } from '../services/data.service';
import { Routes, RouterModule, Router, ActivatedRoute  } from '@angular/router';
@Component({
  selector: 'contact-list',
  templateUrl: './contact-list.component.html',
  styleUrls: [ './contact-list.component.css' ]
})
export class ContactListComponent implements OnInit  {
  name = 'Contact List';
  displayedColumns = ['name', 'email', 'phone'];
  dataSource;
  contacts: Contact[];

  constructor(
    private userService: UserService, private dataService: DataService, private router: Router
   
  ) {}

  ngOnInit() {
    this.userService.getUsers()
      .subscribe((contacts: Contact[]) => {
        this.contacts = contacts;
        this.dataSource = new MatTableDataSource(contacts);
        
      });
  }

  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }
  showContactDetails(value) {
    this.dataService.setSharedData(value);
      this.router.navigate(['contact-info']);
  }
}

