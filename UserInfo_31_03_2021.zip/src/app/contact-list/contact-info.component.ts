import { Component, OnInit } from '@angular/core';
import {MatTableDataSource} from '@angular/material/table';
import { UserService } from '../services/user.service';
import {Contact} from '../interfaces/contact.interface';
import { DataService } from '../services/data.service';
import { Routes, RouterModule, Router, ActivatedRoute  } from '@angular/router';
@Component({
  selector: 'contact-info',
  templateUrl: './contact-info.component.html',
  styleUrls: [ './contact-info.component.css' ]
})
export class ContactInfoComponent implements OnInit  {

  data: any;
  constructor(
    private userService: UserService, private dataService: DataService,  private router: Router
   
  ) {}

  ngOnInit() {
    this.dataService.getSharedData().subscribe(data => this.data = data);
  }

  backtoContactList() {
    this.dataService.setSharedData(null);
    this.router.navigate(['contact-list']);
  }



}

