import { Injectable } from '@angular/core';
import { Observable, BehaviorSubject, ReplaySubject } from 'rxjs';
@Injectable()
export class DataService {
    public dataShared: BehaviorSubject<any> = new BehaviorSubject<any>(null);
 
    constructor() {

    }
    getSharedData(): Observable<any> {
        return this.dataShared.asObservable();
        }
        setSharedData(data: any) {
        this.dataShared.next(data);
        }

}





